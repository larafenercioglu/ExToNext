Group No: 1
Group Project Name: ExToNext
Project Description
People want to close out their unnecessary items since they do not use them anymore. 
Also, people sometimes buy items they will not use in the future. 
Because of that there is a huge consumption problem. For that reason, to avoid unnecessary 
consumerism, there is a need for a social network program that will be a desktop application.
This platform will enable people to exchange and/or sell their items. 
Moreover, this platform will also allow people to donate their items to needy people or 
foundations. Items will be added to the program by the users. According to the seller’s wish, 
items can be exchanged with another item, can be sold ordonated. Eventually, the platform 
will be available for all people who want to share their items. Hopefully, our social network 
platform will help a lot of people to find what they’re looking for.
Current Status: About finished, but we still have to combine GUI with database
Group Members: Lara Fenercioğlu, Bilgehan Akcan, İlke Kaş, Zeynep Büşra Ziyagil, Umut Ege Özdemir, Selahattin Cem Öztürk
Contribution: Database classes and sql implementation to java has done by Lara and İlke. UI part of the project has handled 
by Umut, Bilgehan and Zeynep. Cem has dealed with the message part.
Tools, Organization, Libraries: Java is the main part of the program. MySQL Workbench has used for SQL and database. Apache NetBeans IDE 11.2 has used for GUI.
We wrote test methods to run and test the program and then we implement it to GUI to try. 