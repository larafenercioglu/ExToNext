/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package extonextgroup.extonext_v2;

/**
 *
 * @author DELL
 */
public class Run {

    public static void main(String[] a) {
        new LoginScreen().setVisible(true);
        // new AddDonationListPage().setVisible(true);
        //new AfterDonationPage().setVisible(true);
        //new AfterDonationScreenCorp().setVisible(true);
        //new BuyScreen().setVisible(true);
        //new CorpDonateScreen().setVisible(true);
        //new CorpProfilePage().setVisible(true);
        //new DonationFilteredsearchCorp().setVisible(true);
        //new FilteredBuyScreen().setVisible(true);
        //new ItemDetailsPage().setVisible(true);
        //new MainPageCorporation().setVisible(true);
        //new MainPagePersonal().setVisible(true);
        //new MessagePage().setVisible(true);
        //new PersonalProfilePage().setVisible(true);
        //new SignUpForm().setVisible(true);
        //new UploadScreen().setVisible(true);
        //new WishListListPage().setVisible(true);
        //new WishListPageCorp().setVisible(true);
        //new WishListPagePersonal().setVisible(true);
    }
}
